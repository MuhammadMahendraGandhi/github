# Video Remotion: animasi cerita 9:16 (kartun 2D vektor datar)

1080x1920, 30 fps. Durasi = durasi `public/narasi.mp3` + 1 detik (dihitung otomatis).
Narasi, musik lembut, dan SFX sudah masuk ke komposisi, jadi satu perintah render menghasilkan MP4 bersuara.

## Pakai

```bash
npm install
npm start          # buka Remotion Studio untuk pratinjau
npm run render     # hasil: out/video.mp4
```

Cek tipe: `npm run typecheck` (sama dengan `npx tsc --noEmit`).

## Isi folder

| Path | Fungsi |
| --- | --- |
| `public/narasi.mp3` | Suara final. Hanya dipakai apa adanya + untuk membaca durasi. |
| `public/narasi.srt` | Timing kalimat dari converter. |
| `public/timing.json` | **Sumber timing adegan.** Satu kalimat SRT = satu adegan. Edit bebas. |
| `public/music.mp3`, `public/sfx/*.wav` | Musik dan SFX hasil sintesis (`npm run audio`). |
| `public/naskah.txt` | Teks cerita (diambil dari SRT). |
| `src/scenes.tsx` | 22 ilustrasi SVG, satu per adegan. |
| `src/art.tsx` | Bentuk dasar: karakter, HP, laptop, file, awan, dll. |
| `src/config.ts` | Warna, volume musik/SFX, tombol subtitle. |

## Setel timing sendiri

Buka `public/timing.json`. Tiap adegan punya:

- `start`: detik mulai adegan. Adegan berakhir saat adegan berikutnya mulai.
- `text`: teks subtitle.
- `art`: nama ilustrasi (kunci di `ART` pada `src/scenes.tsx`).
- `step`: nomor langkah di pojok kiri atas, atau `null`.
- `bg`: indeks warna latar (0 sampai 5, lihat `BG` di `src/config.ts`).
- `sfx`: `pop`, `whoosh`, `ding`, `click`, `tada`, atau `none`.

Studio memuat ulang `timing.json` saat dihitung ulang. Kalau tidak berubah, tutup lalu buka lagi tab komposisi `Story`.

Isi ulang dari SRT baru: ganti `public/narasi.srt`, lalu `npm run timing`.
Field `art`, `step`, `bg`, `sfx` yang sudah kamu edit dipertahankan selama jumlah kalimatnya sama.

## Audio

- Matikan subtitle: `SHOW_SUBTITLE = false` di `src/config.ts`.
- Volume musik/SFX: `MUSIC_VOLUME`, `SFX_VOLUME` di `src/config.ts`.
- Buat ulang musik dan SFX: `npm run audio` (butuh Python 3, numpy, scipy, dan ffmpeg).

import React from "react";
import {AbsoluteFill, Audio, Easing, interpolate, Sequence, staticFile, useCurrentFrame, useVideoConfig} from "remotion";
import {ART} from "./scenes";
import {T} from "./art";
import {BG, C, FONT, FPS, HEIGHT, MUSIC_FILE, MUSIC_VOLUME, SFX_VOLUME, SHOW_SUBTITLE, WIDTH} from "./config";
import type {Scene, VideoProps} from "./config";

const Backdrop: React.FC<{bg: string}> = ({bg}) => {
  const f = useCurrentFrame();
  return (
    <AbsoluteFill style={{background: bg}}>
      <svg width={WIDTH} height={HEIGHT} viewBox={`0 0 ${WIDTH} ${HEIGHT}`}>
        <circle cx={140 + Math.sin(f / 70) * 30} cy={300} r={260} fill="#fff" opacity={0.07} />
        <circle cx={960} cy={1120 + Math.cos(f / 60) * 30} r={340} fill="#fff" opacity={0.06} />
        <circle cx={560} cy={1700} r={220} fill="#000" opacity={0.08} />
      </svg>
    </AbsoluteFill>
  );
};

const SceneView: React.FC<{scene: Scene; prevBg: number}> = ({scene, prevBg}) => {
  const f = useCurrentFrame();
  const Art = ART[scene.art] ?? (() => null);
  // Satu transisi konsisten: lingkaran warna baru melebar dari tengah.
  const r = interpolate(f, [0, 14], [0, 150], {extrapolateRight: "clamp", easing: Easing.out(Easing.cubic)});
  const sub = interpolate(f, [4, 10], [0, 1], {extrapolateRight: "clamp"});
  return (
    <AbsoluteFill>
      <Backdrop bg={BG[prevBg % BG.length]} />
      <AbsoluteFill style={{clipPath: `circle(${r}% at 50% 45%)`}}>
        <Backdrop bg={BG[scene.bg % BG.length]} />
        <svg width={WIDTH} height={HEIGHT} viewBox={`0 0 ${WIDTH} ${HEIGHT}`} style={{position: "absolute", inset: 0}}>
          <Art />
          {scene.step !== null && (
            <g transform="translate(150 330)">
              <circle r={64} fill={C.yellow} />
              <T y={26} size={80} fill={C.ink}>{String(scene.step)}</T>
            </g>
          )}
        </svg>
        {SHOW_SUBTITLE && (
          <AbsoluteFill style={{justifyContent: "flex-end", alignItems: "center", paddingBottom: 380, opacity: sub}}>
            <div style={{
              maxWidth: 920, background: C.white, color: C.ink, fontFamily: FONT, fontWeight: 800, fontSize: 58,
              lineHeight: 1.25, textAlign: "center", padding: "26px 40px", borderRadius: 40,
            }}>{scene.text}</div>
          </AbsoluteFill>
        )}
      </AbsoluteFill>
    </AbsoluteFill>
  );
};

export const Story: React.FC<VideoProps> = ({scenes}) => {
  const {durationInFrames} = useVideoConfig();
  const froms = scenes.map((s, i) => (i === 0 ? 0 : Math.round(s.start * FPS)));
  return (
    <AbsoluteFill style={{background: BG[0]}}>
      {scenes.map((s, i) => {
        const to = i + 1 < scenes.length ? froms[i + 1] : durationInFrames;
        return (
          <Sequence key={i} from={froms[i]} durationInFrames={Math.max(1, to - froms[i])}>
            <SceneView scene={s} prevBg={i === 0 ? s.bg : scenes[i - 1].bg} />
          </Sequence>
        );
      })}

      {/* Narasi final: dipakai apa adanya */}
      <Audio src={staticFile("narasi.mp3")} />

      {/* Musik lembut, fade in 1 dtk dan fade out 2 dtk */}
      <Audio
        src={staticFile(MUSIC_FILE)}
        loop
        volume={(f) =>
          MUSIC_VOLUME *
          interpolate(f, [0, FPS, durationInFrames - 2 * FPS, durationInFrames], [0, 1, 1, 0], {
            extrapolateLeft: "clamp", extrapolateRight: "clamp",
          })
        }
      />

      {/* SFX halus di awal tiap adegan */}
      {scenes.map((s, i) =>
        s.sfx && s.sfx !== "none" ? (
          <Sequence key={`sfx-${i}`} from={froms[i]}>
            <Audio src={staticFile(`sfx/${s.sfx}.wav`)} volume={SFX_VOLUME} />
          </Sequence>
        ) : null,
      )}
    </AbsoluteFill>
  );
};

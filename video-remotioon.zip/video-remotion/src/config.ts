export const FPS = 30;
export const WIDTH = 1080;
export const HEIGHT = 1920;

// Palet: indigo malam, teal, kuning matahari, koral, lilac
export const C = {
  ink: "#1B1A47", white: "#FFFFFF", yellow: "#FFC93C", coral: "#FF6B8B", teal: "#19C3B1",
  lilac: "#B9A4FF", sky: "#6EC6FF", skin: "#F4B183", skinDark: "#E39A6B", paper: "#FFFDF5",
  mist: "#F3F0FF", green: "#3DDC84",
};
// Latar per adegan (field "bg" di timing.json)
export const BG = ["#2B2A6B", "#0E8C8C", "#D63F68", "#3B63D9", "#6E48C9", "#C2570C"];
export const FONT = '"Trebuchet MS", "Arial Rounded MT Bold", "Segoe UI", Verdana, sans-serif';

export const MUSIC_FILE = "music.mp3";
export const MUSIC_VOLUME = 0.16;
export const SFX_VOLUME = 0.35;
export const SHOW_SUBTITLE = true;

// Watermark: ganti teks dengan namamu. Kosongkan "" untuk mematikan teks.
export const WATERMARK_TEXT = "@powerrangerkurakura";
// Logo opsional: taruh file di public/ (mis. public/logo.png) lalu isi "logo.png". Kosongkan "" kalau tidak pakai.
export const WATERMARK_LOGO = "";
export const WATERMARK_OPACITY = 0.6;
// "top-right" | "top-left" | "bottom-left" | "bottom-right"
export const WATERMARK_POSITION: "top-right" | "top-left" | "bottom-left" | "bottom-right" = "top-right";

export type Scene = {
  start: number; // detik
  end: number;
  text: string;
  art: string; // nama ilustrasi di src/scenes.tsx
  step: number | null; // nomor langkah di pojok kiri atas
  bg: number; // indeks BG
  sfx: string; // pop | whoosh | ding | click | tada | none
};
export type VideoProps = {scenes: Scene[]};

import React from "react";
import {Composition, staticFile} from "remotion";
import type {CalculateMetadataFunction} from "remotion";
import {getAudioDurationInSeconds} from "@remotion/media-utils";
import {Story} from "./Video";
import {FPS, HEIGHT, WIDTH} from "./config";
import type {VideoProps} from "./config";

// Durasi = durasi narasi + 1 detik. Adegan dibaca dari public/timing.json.
const calculateMetadata: CalculateMetadataFunction<VideoProps> = async () => {
  const [timing, seconds] = await Promise.all([
    fetch(staticFile("timing.json")).then((r) => r.json()),
    getAudioDurationInSeconds(staticFile("narasi.mp3")),
  ]);
  return {durationInFrames: Math.ceil((seconds + 1) * FPS), props: {scenes: timing.scenes}};
};

export const Root: React.FC = () => (
  <Composition
    id="Story"
    component={Story}
    width={WIDTH}
    height={HEIGHT}
    fps={FPS}
    durationInFrames={FPS * 10}
    defaultProps={{scenes: []} as VideoProps}
    calculateMetadata={calculateMetadata}
  />
);

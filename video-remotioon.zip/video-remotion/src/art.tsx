import React from "react";
import {Easing, interpolate, spring, useCurrentFrame, useVideoConfig} from "remotion";
import {C, FONT} from "./config";

type K = {children?: React.ReactNode};

export const useP = (d: number, dur = 20) => {
  const f = useCurrentFrame();
  return interpolate(f, [d, d + dur], [0, 1], {
    extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: Easing.out(Easing.cubic),
  });
};

/** Muncul dengan pantulan kecil. */
export const Pop: React.FC<K & {x?: number; y?: number; s?: number; d?: number; rot?: number}> = ({
  x = 0, y = 0, s = 1, d = 0, rot = 0, children,
}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const k = spring({frame: f - d, fps, config: {damping: 11, stiffness: 150}});
  return (
    <g transform={`translate(${x} ${y}) rotate(${rot}) scale(${Math.max(0.0001, s * k)})`} opacity={Math.min(1, k * 2)}>
      {children}
    </g>
  );
};

export const Bob: React.FC<K & {amp?: number; speed?: number}> = ({amp = 10, speed = 1, children}) => {
  const f = useCurrentFrame();
  return <g transform={`translate(0 ${Math.sin((f / 15) * speed) * amp})`}>{children}</g>;
};

/** Terbang dari titik A ke B. */
export const Fly: React.FC<K & {from: [number, number]; to: [number, number]; d?: number; dur?: number; s?: number}> = ({
  from, to, d = 0, dur = 24, s = 1, children,
}) => {
  const p = useP(d, dur);
  const x = from[0] + (to[0] - from[0]) * p;
  const y = from[1] + (to[1] - from[1]) * p;
  return <g transform={`translate(${x} ${y}) scale(${s})`} opacity={Math.min(1, p * 6)}>{children}</g>;
};

export const T: React.FC<K & {x?: number; y?: number; size?: number; fill?: string; anchor?: "start" | "middle" | "end"}> = ({
  x = 0, y = 0, size = 48, fill = C.white, anchor = "middle", children,
}) => (
  <text x={x} y={y} fontFamily={FONT} fontWeight={800} fontSize={size} fill={fill} textAnchor={anchor}>{children}</text>
);

export const Sparkle: React.FC<{x?: number; y?: number; s?: number; d?: number; color?: string}> = ({
  x = 0, y = 0, s = 1, d = 0, color = C.yellow,
}) => {
  const f = useCurrentFrame();
  const tw = 1 + 0.18 * Math.sin(f / 8 + d);
  return (
    <Pop x={x} y={y} s={s * tw} d={d}>
      <path d="M0 -44 Q7 -7 44 0 Q7 7 0 44 Q-7 7 -44 0 Q-7 -7 0 -44Z" fill={color} />
    </Pop>
  );
};

export const Lines: React.FC<{
  x?: number; y?: number; w: number; n: number; gap?: number; h?: number; color?: string; d?: number; widths?: number[];
}> = ({x = 0, y = 0, w, n, gap = 30, h = 14, color = C.ink, d = 0, widths}) => {
  const f = useCurrentFrame();
  return (
    <g>
      {Array.from({length: n}, (_, i) => {
        const p = interpolate(f, [d + i * 6, d + i * 6 + 16], [0, 1], {extrapolateLeft: "clamp", extrapolateRight: "clamp"});
        return <rect key={i} x={x} y={y + i * gap} width={w * (widths?.[i] ?? 1) * p} height={h} rx={h / 2} fill={color} />;
      })}
    </g>
  );
};

export const Phone: React.FC<K & {w?: number; h?: number}> = ({w = 320, h = 600, children}) => (
  <g>
    <rect x={-w / 2} y={-h / 2} width={w} height={h} rx={52} fill={C.ink} />
    <rect x={-w / 2 + 14} y={-h / 2 + 14} width={w - 28} height={h - 28} rx={40} fill={C.mist} />
    <rect x={-34} y={-h / 2 + 24} width={68} height={14} rx={7} fill={C.ink} />
    {children}
  </g>
);

export const Laptop: React.FC<K> = ({children}) => (
  <g>
    <rect x={-200} y={-130} width={400} height={260} rx={22} fill={C.ink} />
    <rect x={-182} y={-112} width={364} height={224} rx={10} fill="#26327A" />
    {children}
    <path d="M-215 130 H215 L260 168 H-260Z" fill="#CFCBF0" />
  </g>
);

export const Character: React.FC<{mood?: "happy" | "sad" | "neutral"; shirt?: string}> = ({mood = "happy", shirt = C.coral}) => {
  const f = useCurrentFrame();
  const blink = f % 100 < 4 ? 0.12 : 1;
  const mouth =
    mood === "happy" ? "M-32 46 Q0 84 32 46Z" : mood === "sad" ? "M-26 66 Q0 42 26 66" : "M-24 56 H24";
  return (
    <g>
      <path d="M-135 230 Q-135 92 0 92 Q135 92 135 230Z" fill={shirt} />
      <rect x={-24} y={60} width={48} height={50} rx={14} fill={C.skinDark} />
      <circle cx={-98} cy={8} r={19} fill={C.skin} />
      <circle cx={98} cy={8} r={19} fill={C.skin} />
      <circle cx={0} cy={0} r={100} fill={C.skin} />
      <path d="M-104 -6 Q-116 -126 0 -122 Q116 -126 104 -6 Q72 -72 0 -68 Q-72 -72 -104 -6Z" fill={C.ink} />
      <ellipse cx={-38} cy={8} rx={9} ry={11 * blink} fill={C.ink} />
      <ellipse cx={38} cy={8} rx={9} ry={11 * blink} fill={C.ink} />
      <path d={mood === "sad" ? "M-58 -22 L-20 -32 M58 -22 L20 -32" : "M-56 -28 Q-38 -40 -20 -28 M56 -28 Q38 -40 20 -28"}
        stroke={C.ink} strokeWidth={7} strokeLinecap="round" fill="none" />
      <circle cx={-62} cy={44} r={15} fill={C.coral} opacity={0.45} />
      <circle cx={62} cy={44} r={15} fill={C.coral} opacity={0.45} />
      <path d={mouth} stroke={C.ink} strokeWidth={7} strokeLinecap="round" strokeLinejoin="round" fill={mood === "happy" ? C.white : "none"} />
      {mood === "sad" && <path d="M92 -10 Q108 18 92 30 Q76 18 92 -10Z" fill={C.sky} />}
    </g>
  );
};

export const FileCard: React.FC<K & {label: string; color?: string; w?: number; h?: number}> = ({
  label, color = C.yellow, w = 220, h = 280, children,
}) => (
  <g>
    <path d={`M${-w / 2} ${-h / 2} H${w / 2 - 50} L${w / 2} ${-h / 2 + 50} V${h / 2} H${-w / 2}Z`} fill={C.paper} />
    <path d={`M${w / 2 - 50} ${-h / 2} V${-h / 2 + 50} H${w / 2}Z`} fill="#D9D6F2" />
    <rect x={-w / 2 + 24} y={h / 2 - 84} width={w - 48} height={56} rx={16} fill={color} />
    <T y={h / 2 - 44} size={36} fill={C.ink}>{label}</T>
    {children}
  </g>
);

export const Wave: React.FC<{n?: number; w?: number; h?: number; color?: string}> = ({n = 9, w = 14, h = 120, color = C.teal}) => {
  const f = useCurrentFrame();
  return (
    <g>
      {Array.from({length: n}, (_, i) => {
        const bh = h * (0.3 + 0.7 * Math.abs(Math.sin(f / 6 + i * 0.8)));
        return <rect key={i} x={(i - (n - 1) / 2) * w * 1.8 - w / 2} y={-bh / 2} width={w} height={bh} rx={w / 2} fill={color} />;
      })}
    </g>
  );
};

export const Arrow: React.FC<{color?: string; rot?: number; s?: number}> = ({color = C.white, rot = 0, s = 1}) => (
  <g transform={`rotate(${rot}) scale(${s})`}>
    <path d="M-70 0 H50 M18 -34 L58 0 L18 34" stroke={color} strokeWidth={22} strokeLinecap="round" strokeLinejoin="round" fill="none" />
  </g>
);

export const Cloud: React.FC<{color?: string}> = ({color = C.white}) => (
  <path d="M-150 60 Q-210 60 -200 0 Q-195 -50 -140 -50 Q-120 -130 -40 -120 Q10 -170 80 -110 Q170 -120 175 -40 Q230 -20 215 40 Q205 60 160 60Z" fill={color} />
);

export const Folder: React.FC<{color?: string}> = ({color = C.lilac}) => (
  <g>
    <path d="M-120 -80 H-30 L0 -48 H120 V90 H-120Z" fill={C.ink} opacity={0.35} />
    <rect x={-120} y={-36} width={240} height={126} rx={16} fill={color} />
  </g>
);

export const Gear: React.FC<{color?: string; r?: number}> = ({color = C.yellow, r = 60}) => {
  const f = useCurrentFrame();
  return (
    <g transform={`rotate(${f * 3})`}>
      {Array.from({length: 8}, (_, i) => (
        <rect key={i} x={-12} y={-r - 20} width={24} height={34} rx={6} fill={color} transform={`rotate(${i * 45})`} />
      ))}
      <circle r={r} fill={color} />
      <circle r={r * 0.4} fill={C.ink} />
    </g>
  );
};

export const Bulb: React.FC = () => (
  <g>
    <circle r={110} fill={C.yellow} opacity={0.25} />
    <circle r={70} fill={C.yellow} />
    <rect x={-34} y={62} width={68} height={44} rx={12} fill={C.white} />
    <rect x={-26} y={110} width={52} height={20} rx={10} fill={C.ink} />
    <path d="M-24 -10 L-10 20 L0 -6 L10 20 L24 -10" stroke={C.ink} strokeWidth={8} strokeLinecap="round" strokeLinejoin="round" fill="none" />
  </g>
);

export const Hourglass: React.FC = () => {
  const f = useCurrentFrame();
  const sand = 0.5 + 0.5 * Math.sin(f / 20);
  return (
    <g>
      <rect x={-70} y={-110} width={140} height={22} rx={11} fill={C.ink} />
      <rect x={-70} y={88} width={140} height={22} rx={11} fill={C.ink} />
      <path d="M-56 -88 H56 L8 0 L56 88 H-56 L-8 0Z" fill={C.white} opacity={0.9} />
      <path d={`M-40 ${88 - 60 * sand} H40 L50 88 H-50Z`} fill={C.yellow} />
      <path d={`M-${30 * (1 - sand) + 6} -80 H${30 * (1 - sand) + 6} L0 -20Z`} fill={C.yellow} />
    </g>
  );
};

export const Heart: React.FC<{color?: string}> = ({color = C.coral}) => (
  <path d="M0 44 C-92 -14 -56 -80 0 -34 C56 -80 92 -14 0 44Z" fill={color} />
);

export const Check: React.FC<{color?: string}> = ({color = C.green}) => (
  <g>
    <circle r={52} fill={color} />
    <path d="M-24 2 L-6 22 L26 -16" stroke={C.white} strokeWidth={14} strokeLinecap="round" strokeLinejoin="round" fill="none" />
  </g>
);

export const Bubble: React.FC<K & {w: number; h: number; color?: string; side?: "left" | "right"}> = ({
  w, h, color = C.white, side = "left", children,
}) => (
  <g>
    <rect x={-w / 2} y={-h / 2} width={w} height={h} rx={28} fill={color} />
    <path d={side === "left" ? `M${-w / 2 + 24} ${h / 2 - 4} l-14 26 l40 -22Z` : `M${w / 2 - 24} ${h / 2 - 4} l14 26 l-40 -22Z`} fill={color} />
    {children}
  </g>
);

export const Confetti: React.FC = () => {
  const f = useCurrentFrame();
  const cols = [C.yellow, C.coral, C.teal, C.white, C.sky];
  return (
    <g>
      {Array.from({length: 36}, (_, i) => {
        const x = (i * 173) % 1080;
        const y = ((i * 97) % 700) - 700 + ((f * (7 + (i % 5))) % 2300);
        return <rect key={i} x={x} y={y} width={16} height={26} rx={4} fill={cols[i % 5]} transform={`rotate(${f * 4 + i * 40} ${x} ${y})`} />;
      })}
    </g>
  );
};

import React from "react";
import {interpolate, useCurrentFrame} from "remotion";
import {
  Arrow, Bob, Bubble, Bulb, Character, Check, Cloud, Confetti, FileCard, Fly, Folder, Gear, Heart, Hourglass,
  Laptop, Lines, Phone, Pop, Sparkle, T, Wave, useP,
} from "./art";
import {C} from "./config";

const Chat: React.FC<{mine?: boolean}> = ({mine = true}) => (
  <g>
    <circle cx={-100} cy={-236} r={26} fill={C.coral} />
    <Lines x={-60} y={-244} w={140} n={1} h={16} color={C.lilac} d={4} />
    <g transform="translate(-30 -120)"><Bubble w={190} h={100}><Lines x={-70} y={-24} w={140} n={3} gap={24} h={12} color={C.ink} d={8} widths={[1, 0.8, 0.5]} /></Bubble></g>
    {mine && <g transform="translate(30 20)"><Bubble w={190} h={90} color={C.teal} side="right"><Lines x={-70} y={-20} w={140} n={2} gap={26} h={12} color={C.white} d={22} widths={[1, 0.6]} /></Bubble></g>}
    <rect x={-120} y={208} width={240} height={52} rx={26} fill={C.white} />
  </g>
);

const Tap: React.FC<{x: number; y: number; at: number}> = ({x, y, at}) => {
  const f = useCurrentFrame();
  const r = interpolate(f, [at, at + 18], [8, 70], {extrapolateLeft: "clamp", extrapolateRight: "clamp"});
  const o = interpolate(f, [at, at + 18], [0.9, 0], {extrapolateLeft: "clamp", extrapolateRight: "clamp"});
  return <circle cx={x} cy={y} r={r} fill="none" stroke={C.white} strokeWidth={10} opacity={o} />;
};

const Mini: React.FC<{label: string; color?: string}> = ({label, color = C.yellow}) => (
  <g><rect x={-90} y={-60} width={180} height={120} rx={22} fill={color} /><T y={22} size={52} fill={C.ink}>{label}</T></g>
);

export const ART: Record<string, React.FC> = {
  laptopNo: () => (
    <>
      <Pop x={290} y={900} s={1.25}><Bob amp={4}><Character mood="sad" /></Bob></Pop>
      <Pop x={730} y={760} s={1.3} d={6}><Laptop><Lines x={-140} y={-72} w={280} n={5} gap={38} h={16} color={C.teal} d={12} widths={[0.9, 0.6, 1, 0.5, 0.8]} /></Laptop></Pop>
      <Pop x={730} y={560} d={14} rot={-10}><rect x={-80} y={-34} width={160} height={68} rx={34} fill={C.yellow} /><T y={16} size={44} fill={C.ink}>$$$</T></Pop>
      <Pop x={730} y={770} s={1.7} d={28}>
        <path d="M-90 -90 L90 90 M90 -90 L-90 90" stroke={C.white} strokeWidth={50} strokeLinecap="round" />
        <path d="M-90 -90 L90 90 M90 -90 L-90 90" stroke={C.coral} strokeWidth={30} strokeLinecap="round" />
      </Pop>
    </>
  ),
  phoneHero: () => (
    <>
      <Pop x={290} y={960} s={1.2}><Bob amp={5}><Character mood="happy" shirt={C.yellow} /></Bob></Pop>
      <Pop x={730} y={720} s={1.3} d={8}>
        <Bob amp={8}>
          <Phone>
            <rect x={-134} y={-260} width={268} height={360} rx={26} fill={C.teal} />
            <path d="M-34 -120 L50 -70 L-34 -20Z" fill={C.white} />
            <rect x={-110} y={130} width={220} height={34} rx={17} fill={C.white} />
            <rect x={-110} y={190} width={140} height={20} rx={10} fill={C.lilac} />
          </Phone>
        </Bob>
      </Pop>
      <Sparkle x={930} y={420} d={20} s={1.2} /><Sparkle x={480} y={440} d={30} s={0.8} color={C.white} />
    </>
  ),
  trio: () => (
    <>
      {[
        {x: 200, c: C.ink, l: "Claude", d: 0, i: <path d="M0 -50 Q8 -8 50 0 Q8 8 0 50 Q-8 8 -50 0 Q-8 -8 0 -50Z" fill={C.coral} />},
        {x: 540, c: C.teal, l: "MiniMax", d: 8, i: <Wave n={5} w={14} h={90} color={C.white} />},
        {x: 880, c: C.lilac, l: "GitHub", d: 16, i: (
          <g stroke={C.ink} strokeWidth={10} fill={C.white}><path d="M-30 -40 V40 M-30 -4 Q30 -4 30 -40" fill="none" /><circle cx={-30} cy={-44} r={14} /><circle cx={-30} cy={44} r={14} /><circle cx={30} cy={-44} r={14} /></g>
        )},
      ].map((b) => (
        <Pop key={b.l} x={b.x} y={760} d={b.d}>
          <Bob amp={7} speed={0.8 + b.d / 40}><circle r={120} fill={b.c} />{b.i}<T y={200} size={52}>{b.l}</T></Bob>
        </Pop>
      ))}
    </>
  ),
  chatOpen: () => (
    <>
      <Pop x={540} y={780} s={1.45}><Bob amp={6}><Phone><Chat mine={false} /></Phone></Bob></Pop>
      <Sparkle x={160} y={420} d={14} s={1.3} /><Sparkle x={930} y={520} d={22} /><Sparkle x={200} y={1000} d={30} s={0.7} color={C.white} />
    </>
  ),
  promptTyping: () => (
    <>
      <Pop x={400} y={780} s={1.3}><Phone><Chat /></Phone></Pop>
      <Pop x={830} y={700} d={50} rot={6}>
        <rect x={-130} y={-170} width={260} height={340} rx={22} fill={C.paper} />
        <Lines x={-90} y={-120} w={180} n={6} gap={44} h={14} color={C.ink} d={56} widths={[1, 0.7, 0.9, 0.6, 1, 0.4]} />
      </Pop>
      <Sparkle x={830} y={480} d={60} />
    </>
  ),
  shortLines: () => (
    <>
      <Pop x={540} y={760}>
        <rect x={-260} y={-330} width={520} height={660} rx={36} fill={C.paper} />
        {[0.55, 0.8, 0.45, 0.7, 0.6, 0.85].map((w, i) => (
          <g key={i} transform={`translate(-200 ${-250 + i * 100})`}>
            <Pop d={10 + i * 7}><Check /></Pop>
            <Lines x={50} y={-8} w={340} n={1} h={20} color={C.ink} d={10 + i * 7} widths={[w]} />
          </g>
        ))}
      </Pop>
      <Pop x={880} y={1000} d={40}><Wave n={5} w={14} h={110} color={C.yellow} /></Pop>
    </>
  ),
  copyToTts: () => (
    <>
      <Pop x={230} y={760}><rect x={-120} y={-160} width={240} height={320} rx={24} fill={C.paper} /><Lines x={-80} y={-110} w={160} n={5} gap={46} h={14} d={6} widths={[1, 0.7, 0.9, 0.5, 0.8]} /></Pop>
      <Pop x={540} y={760} d={18}><Bob amp={6}><Arrow s={1.1} /></Bob></Pop>
      <Pop x={850} y={760} d={30}><rect x={-140} y={-180} width={280} height={360} rx={36} fill={C.white} /><circle cy={-100} r={44} fill={C.coral} /><Wave n={7} w={14} h={110} color={C.ink} /></Pop>
    </>
  ),
  ttsPanel: () => (
    <>
      <Pop x={540} y={780}>
        <rect x={-400} y={-390} width={800} height={780} rx={48} fill={C.white} />
        <rect x={-340} y={-330} width={680} height={290} rx={28} fill={C.mist} />
        <Lines x={-300} y={-280} w={600} n={4} gap={52} h={18} color={C.lilac} d={10} widths={[1, 0.9, 1, 0.5]} />
        <rect x={-340} y={10} width={420} height={84} rx={42} fill="#E9E4FF" />
        <T x={-300} y={66} size={38} fill={C.ink} anchor="start">Pilih suara</T>
        <path d="M30 40 L50 64 L70 40Z" fill={C.ink} />
        <g transform="translate(0 250)"><Bob amp={0}><rect x={-340} y={-55} width={680} height={110} rx={55} fill={C.coral} /><T y={18} size={56}>Generate</T></Bob></g>
        <Tap x={0} y={250} at={70} />
      </Pop>
    </>
  ),
  mp3Download: () => (
    <>
      <Pop x={540} y={640} s={1.5}><Bob amp={6}><FileCard label="MP3" color={C.teal}><Wave n={7} w={9} h={70} color={C.coral} /></FileCard></Bob></Pop>
      <Pop x={540} y={1010} d={14}><Bob amp={14} speed={1.6}><Arrow rot={90} s={1.3} /></Bob></Pop>
      <Pop x={540} y={1170} d={20}><rect x={-240} y={-18} width={480} height={36} rx={18} fill={C.white} opacity={0.9} /></Pop>
    </>
  ),
  converter: () => (
    <>
      <Pop x={170} y={760} s={0.95}><FileCard label="MP3" color={C.teal} /></Pop>
      <Pop x={340} y={760} d={10} s={0.7}><Arrow /></Pop>
      <Pop x={540} y={760} d={16}><Gear /></Pop>
      <Pop x={740} y={760} d={22} s={0.7}><Arrow /></Pop>
      <Pop x={910} y={760} d={28} s={0.95}><FileCard label="SRT" color={C.coral} /></Pop>
    </>
  ),
  uploadCloud: () => {
    const p = useP(20, 70);
    return (
      <>
        <Pop x={540} y={620} s={1.4}><Bob amp={6}><Cloud /><g transform="translate(0 0)"><Arrow rot={-90} color={C.ink} s={1.2} /></g></Bob></Pop>
        <Fly from={[540, 1130]} to={[540, 870]} d={10} dur={40} s={0.6}><FileCard label="MP3" color={C.teal} /></Fly>
        <Pop x={540} y={1250} d={6}>
          <rect x={-300} y={-22} width={600} height={44} rx={22} fill={C.white} opacity={0.3} />
          <rect x={-300} y={-22} width={600 * p} height={44} rx={22} fill={C.yellow} />
        </Pop>
      </>
    );
  },
  srtFile: () => (
    <>
      <Pop x={540} y={720} s={1.7}>
        <FileCard label="SRT" color={C.coral}>
          {[0, 1, 2].map((i) => (
            <g key={i} transform={`translate(-80 ${-100 + i * 52})`}>
              <rect width={58} height={22} rx={11} fill={C.coral} />
              <Lines x={68} y={4} w={92} n={1} h={14} d={14 + i * 8} widths={[1 - i * 0.2]} />
            </g>
          ))}
        </FileCard>
      </Pop>
      <Pop x={880} y={450} d={24}><ClockFace /></Pop>
    </>
  ),
  sendFiles: () => (
    <>
      <Pop x={540} y={800} s={1.25}><Phone><Chat mine={false} /></Phone></Pop>
      <Fly from={[130, 420]} to={[440, 760]} d={8} dur={26} s={0.6}><FileCard label="MP3" color={C.teal} /></Fly>
      <Fly from={[950, 420]} to={[640, 760]} d={20} dur={26} s={0.6}><FileCard label="SRT" color={C.coral} /></Fly>
      <Pop x={800} y={520} d={56}><Check /></Pop>
    </>
  ),
  zipBox: () => (
    <>
      <Pop x={540} y={760}>
        <Bob amp={8}>
          <rect x={-190} y={-240} width={380} height={480} rx={40} fill={C.yellow} />
          {Array.from({length: 11}, (_, i) => <rect key={i} x={i % 2 ? 2 : -22} y={-240 + i * 20} width={20} height={12} rx={4} fill={C.ink} />)}
          <rect x={-26} y={-30} width={52} height={70} rx={18} fill={C.coral} />
          <T y={170} size={96} fill={C.ink}>ZIP</T>
        </Bob>
      </Pop>
      <Sparkle x={200} y={500} d={20} s={1.2} /><Sparkle x={900} y={980} d={30} /><Sparkle x={880} y={420} d={38} s={0.7} color={C.white} />
    </>
  ),
  newRepo: () => (
    <>
      <Pop x={540} y={720} s={1.8}><Bob amp={5}><Folder /></Bob></Pop>
      <Pop x={730} y={560} d={18}><circle r={62} fill={C.teal} /><path d="M-30 0 H30 M0 -30 V30" stroke={C.white} strokeWidth={14} strokeLinecap="round" /></Pop>
      <Pop x={540} y={1090} d={28}><rect x={-250} y={-44} width={500} height={88} rx={44} fill={C.white} /><T y={16} size={44} fill={C.ink}>video-remotion</T></Pop>
    </>
  ),
  uploadZip: () => (
    <>
      <Pop x={540} y={940} s={1.5}><Folder color={C.yellow} /></Pop>
      <Fly from={[540, 380]} to={[540, 800]} d={10} dur={34}><Mini label="ZIP" color={C.coral} /></Fly>
      <Pop x={540} y={430} d={6}><Bob amp={10} speed={1.5}><Arrow rot={90} s={0.8} /></Bob></Pop>
      <Pop x={830} y={640} d={50}><Check /></Pop>
    </>
  ),
  codespace: () => (
    <>
      <Pop x={540} y={470} s={1.1}><Bob amp={7}><Cloud /></Bob></Pop>
      <Pop x={540} y={940} d={10}>
        <rect x={-380} y={-220} width={760} height={440} rx={32} fill={C.ink} />
        {[C.coral, C.yellow, C.teal].map((c, i) => <circle key={i} cx={-330 + i * 40} cy={-176} r={13} fill={c} />)}
        <Lines x={-330} y={-120} w={560} n={4} gap={46} h={16} color={C.teal} d={20} widths={[0.5, 0.8, 0.65, 0.4]} />
        <T x={-330} y={150} size={56} fill={C.yellow} anchor="start">{">_"}</T>
      </Pop>
    </>
  ),
  extract: () => (
    <>
      <Pop x={200} y={760} s={1.3}><Mini label="ZIP" color={C.yellow} /></Pop>
      <Pop x={380} y={760} d={10} s={0.7}><Arrow /></Pop>
      {[["src", 520], ["public", 760], ["out", 1000]].map(([l, y], i) => (
        <Pop key={l} x={600} y={Number(y)} s={0.62} d={16 + i * 8}>
          <Folder color={C.lilac} /><T x={190} y={50} size={72} anchor="start">{String(l)}</T>
        </Pop>
      ))}
      <Fly from={[260, 1180]} to={[600, 780]} d={44} dur={28} s={0.45}><FileCard label="MP3" color={C.teal} /></Fly>
    </>
  ),
  videoDownload: () => (
    <>
      <Pop x={500} y={740} s={1.3}>
        <Phone>
          <rect x={-134} y={-250} width={268} height={420} rx={26} fill={C.coral} />
          <path d="M-34 -110 L50 -60 L-34 -10Z" fill={C.white} />
          <rect x={-110} y={110} width={220} height={16} rx={8} fill={C.white} opacity={0.4} />
          <rect x={-110} y={110} width={220 * useP(20, 60)} height={16} rx={8} fill={C.yellow} />
        </Phone>
      </Pop>
      <Pop x={840} y={1040} d={16}><Bob amp={12} speed={1.5}><circle r={80} fill={C.teal} /><Arrow rot={90} s={0.75} /></Bob></Pop>
      <Pop x={850} y={500} d={70}><Check /></Pop>
    </>
  ),
  celebrate: () => (
    <>
      <Confetti />
      <Pop x={380} y={900} s={1.3}><Bob amp={8}><Character mood="happy" shirt={C.teal} /></Bob></Pop>
      <Pop x={760} y={740} s={0.95} d={8} rot={10}><Phone><rect x={-134} y={-250} width={268} height={420} rx={26} fill={C.yellow} /><path d="M-34 -110 L50 -60 L-34 -10Z" fill={C.ink} /></Phone></Pop>
      <Sparkle x={540} y={440} d={14} s={1.6} /><Sparkle x={920} y={420} d={26} /><Sparkle x={160} y={560} d={34} color={C.white} />
    </>
  ),
  recipe: () => (
    <>
      <Pop x={190} y={800} s={0.95}><Phone w={260} h={500} /></Pop>
      <Pop x={365} y={800} d={10}><T size={110}>+</T></Pop>
      <Pop x={540} y={800} d={14} s={1.3}><Bob amp={9}><Bulb /></Bob></Pop>
      <Pop x={715} y={800} d={22}><T size={110}>+</T></Pop>
      <Pop x={890} y={800} d={26} s={1.3}><Hourglass /></Pop>
    </>
  ),
  comments: () => (
    <>
      <Pop x={340} y={800} s={1.2}><Phone><Chat mine={false} /></Phone></Pop>
      <Pop x={790} y={560} d={14}><Bubble w={300} h={120} color={C.coral} side="left"><Lines x={-110} y={-24} w={220} n={2} gap={30} h={14} color={C.white} d={20} widths={[1, 0.6]} /></Bubble></Pop>
      <Pop x={790} y={800} d={30}><Bubble w={300} h={120} side="right">{[-50, 0, 50].map((x, i) => <circle key={i} cx={x} cy={0} r={14} fill={C.ink} />)}</Bubble></Pop>
      <Pop x={850} y={1050} d={44} s={1.6}><Bob amp={10} speed={1.4}><Heart /></Bob></Pop>
    </>
  ),
};

const ClockFace: React.FC = () => {
  const f = useCurrentFrame();
  return (
    <g>
      <circle r={80} fill={C.white} />
      <path d={`M0 0 L0 -50`} stroke={C.ink} strokeWidth={10} strokeLinecap="round" transform={`rotate(${f * 6})`} />
      <path d="M0 0 L34 14" stroke={C.coral} strokeWidth={10} strokeLinecap="round" />
    </g>
  );
};

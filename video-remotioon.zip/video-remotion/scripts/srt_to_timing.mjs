// Isi public/timing.json dari public/narasi.srt.  Jalankan: npm run timing
// Satu kalimat SRT = satu adegan. Field art/step/bg/sfx yang sudah kamu edit di timing.json
// dipertahankan (per urutan adegan) selama jumlah adegannya tidak berubah.
import fs from "node:fs";

const SRT = "public/narasi.srt", OUT = "public/timing.json";
const FIX = [[/Mini Max/gi, "MiniMax"], [/code ?spaces/gi, "Codespaces"], [/remotion/gi, "Remotion"],
  [/folder publik/gi, "folder public"], [/Web Converter/g, "web converter"], [/repositori/gi, "repository"]];

// Bawaan: [art, step, bg, sfx] per adegan
const DEFAULTS = [
  ["laptopNo", null, 0, "pop"], ["phoneHero", null, 1, "whoosh"], ["trio", null, 2, "pop"],
  ["chatOpen", 1, 3, "whoosh"], ["promptTyping", 1, 3, "click"], ["shortLines", 1, 3, "pop"],
  ["copyToTts", 2, 4, "whoosh"], ["ttsPanel", 2, 4, "click"], ["mp3Download", 2, 4, "ding"],
  ["converter", 3, 5, "whoosh"], ["uploadCloud", 3, 5, "pop"], ["srtFile", 3, 5, "ding"],
  ["sendFiles", 4, 0, "whoosh"], ["zipBox", 4, 0, "pop"], ["newRepo", 5, 1, "whoosh"],
  ["uploadZip", 5, 1, "pop"], ["codespace", 6, 2, "whoosh"], ["extract", 6, 2, "click"],
  ["videoDownload", 7, 3, "ding"], ["celebrate", null, 4, "tada"], ["recipe", null, 5, "pop"],
  ["comments", null, 0, "ding"],
];

const toSec = (s) => { const [h, m, r] = s.split(":"); return +h * 3600 + +m * 60 + +r.replace(",", "."); };
const blocks = fs.readFileSync(SRT, "utf8").replace(/\r/g, "").trim().split(/\n\s*\n/);
const items = blocks.map((b) => {
  const l = b.split("\n"); const [a, z] = l[1].split(" --> ");
  return { start: toSec(a), end: toSec(z), text: l.slice(2).join(" ").trim() };
}).filter((x) => x.end > x.start && !/Transcribed by|UniScribe/i.test(x.text));

let old = [];
try { old = JSON.parse(fs.readFileSync(OUT, "utf8")).scenes ?? []; } catch {}
const keep = old.length === items.length;

const scenes = items.map((it, i) => {
  let text = it.text; for (const [re, to] of FIX) text = text.replace(re, to);
  const d = DEFAULTS[i % DEFAULTS.length], o = keep ? old[i] : {};
  return {
    start: i === 0 ? 0 : +it.start.toFixed(3), end: +it.end.toFixed(3), text,
    art: o.art ?? d[0], step: o.step === undefined ? d[1] : o.step, bg: o.bg ?? d[2], sfx: o.sfx ?? d[3],
  };
});
fs.writeFileSync(OUT, JSON.stringify({ scenes }, null, 2));
console.log(`timing.json: ${scenes.length} adegan`);

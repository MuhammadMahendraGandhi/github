#!/usr/bin/env python3
"""Sintesis musik lembut + SFX halus ke public/. Jalankan: python3 scripts/make_audio.py
Butuh: numpy, scipy, ffmpeg (opsional, untuk musik .mp3)."""
import os, subprocess, numpy as np
from scipy.io import wavfile
from scipy.signal import butter, lfilter

SR = 32000
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "public")
os.makedirs(os.path.join(OUT, "sfx"), exist_ok=True)
rng = np.random.default_rng(7)

def t(sec): return np.arange(int(sec * SR)) / SR
def midi(n): return 440.0 * 2 ** ((n - 69) / 12)
def env(n, a, r):
    e = np.ones(n); a = int(a * SR); r = int(r * SR)
    e[:a] = np.linspace(0, 1, a); e[-r:] *= np.linspace(1, 0, r); return e
def save(name, x, peak=0.8):
    x = x / (np.max(np.abs(x)) + 1e-9) * peak
    wavfile.write(os.path.join(OUT, name), SR, (x * 32767).astype(np.int16))
def lp(x, hz, order=2):
    b, a = butter(order, hz / (SR / 2), "low"); return lfilter(b, a, x)

# ---------- musik: 4 akor x 3 dtk, diulang 96 dtk ----------
chords = [[60, 64, 67, 71], [57, 60, 64, 67], [53, 57, 60, 64], [55, 59, 62, 65]]
bar, beat, total = 3.0, 0.75, 96.0
music = np.zeros(int(total * SR))
for i in range(int(total / bar)):
    ch = chords[i % 4]; s = int(i * bar * SR); tt = t(bar)
    pad = sum(np.sin(2 * np.pi * midi(n) * tt) + 0.5 * np.sin(2 * np.pi * midi(n) * 1.003 * tt) for n in ch)
    pad = lp(pad, 1400) * env(len(tt), 0.9, 0.9) * 0.10
    bass = np.sin(2 * np.pi * midi(ch[0] - 12) * tt) * env(len(tt), 0.1, 0.6) * 0.22
    seg = pad + bass
    for k in range(4):
        note = ch[[0, 2, 1, 3][k]] + 12
        tk = t(beat * 1.6)
        pl = np.sin(2 * np.pi * midi(note) * tk) * np.exp(-tk * 4.5) * 0.16
        o = int(k * beat * SR); seg[o:o + len(pl)] += pl[: len(seg) - o]
    music[s:s + len(seg)] += seg[: len(music) - s]
tm = t(total)
music *= np.clip(np.minimum(tm / 1.5, (total - tm) / 2.0), 0, 1)
save("music.wav", music, 0.6)
try:
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", os.path.join(OUT, "music.wav"),
                    "-b:a", "128k", os.path.join(OUT, "music.mp3")], check=True)
    os.remove(os.path.join(OUT, "music.wav"))
except Exception:
    print("ffmpeg tidak ada: music.wav tetap dipakai, ubah MUSIC_FILE di src/config.ts")

# ---------- SFX halus ----------
tt = t(0.22); save("sfx/pop.wav", np.sin(2 * np.pi * (520 + 700 * np.exp(-tt * 30)) * tt) * np.exp(-tt * 20), 0.5)
tt = t(0.6); w = lp(rng.standard_normal(len(tt)), 2500) * np.sin(np.pi * tt / 0.6) ** 2
save("sfx/whoosh.wav", w, 0.4)
tt = t(0.9); save("sfx/ding.wav", (np.sin(2 * np.pi * 1318 * tt) + 0.4 * np.sin(2 * np.pi * 2637 * tt)) * np.exp(-tt * 5), 0.45)
tt = t(0.08); save("sfx/click.wav", rng.standard_normal(len(tt)) * np.exp(-tt * 70), 0.35)
x = np.zeros(int(1.4 * SR))
for i, n in enumerate([72, 76, 79, 84]):
    tk = t(1.0); o = int(i * 0.11 * SR); y = np.sin(2 * np.pi * midi(n) * tk) * np.exp(-tk * 4.5)
    x[o:o + len(y)] += y[: len(x) - o]
save("sfx/tada.wav", x, 0.45)
print("audio selesai")
